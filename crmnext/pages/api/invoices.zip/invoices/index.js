// /pages/api/invoices/index.js
import dbConnect from "../../../utils/dbConnect";
import Invoice from "../../../models/Invoice/Invoice";

export default async function handler(req, res) {
  await dbConnect();

  if (req.method === "POST") {
    if (req.method === "POST") {
      try {
        const invoice = await Invoice.create(req.body);
        res.status(200).json({ success: true, data: invoice });
      } catch (error) {
        console.error("Create Invoice Error:", error.message);
        res.status(400).json({ success: false, message: error.message });
      }
    } else {
      res.setHeader("Allow", ["POST"]);
      res.status(405).end(`Method ${req.method} Not Allowed`);
    }
    try {
      const {
        invoiceNumber,
        invoiceDate,
        platform,
        status,
        buyer,
        seller,
        items,
        payment,
        totalAmount,
        totalGST,
        grandTotal,
        notes,
        createdBy,
      } = req.body;

      const statusTracker = [
        {
          status: "Created",
          updatedAt: new Date(),
          updatedBy: createdBy || { userId: null, role: "system" },
        },
      ];

      const invoice = await Invoice.create({
        invoiceNumber,
        invoiceDate,
        platform,
        status,
        buyer,
        seller,
        items,
        payment,
        totalAmount,
        totalGST,
        grandTotal,
        notes,
        createdBy,
        statusTracker,
      });

      return res.status(201).json({ success: true, invoice });
    } catch (error) {
      console.error("Create Invoice Error:", error);
      return res.status(500).json({ success: false, message: "Server Error" });
    }
  }

  return res
    .status(405)
    .json({ success: false, message: "Method Not Allowed" });
}

import React, { useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";

const InvoiceCreatePage = () => {
  const [invoiceData, setInvoiceData] = useState({
    invoiceId: "EB1F8CE8",
    date: new Date().toISOString().slice(0, 10),
    platform: "",
    status: "Pending",
    buyerName: "",
    buyerGSTIN: "",
    buyerState: "",
    sellerName: "",
    sellerGSTIN: "",
    sellerState: "",
    items: [],
    currentItem: { name: "", price: "", hsn: "" },
    gstType: "",
    cgst: 0,
    sgst: 0,
    igst: 0,
    paymentMode: "",
    isEscrow: false,
    isPartialPayment: false,
    amountPaid: "",
    notes: "",
  });

  const addItem = () => {
    if (invoiceData.currentItem.name && invoiceData.currentItem.price) {
      setInvoiceData((prev) => ({
        ...prev,
        items: [...prev.items, prev.currentItem],
        currentItem: { name: "", price: "", hsn: "" },
      }));
    }
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setInvoiceData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const handleItemChange = (e) => {
    const { name, value } = e.target;
    setInvoiceData((prev) => ({
      ...prev,
      currentItem: {
        ...prev.currentItem,
        [name]: value,
      },
    }));
  };

  return (
    <div className="container my-5">
      <h2 className="mb-4">🧾 Create Invoice</h2>

      {/* Invoice Header */}
      <div className="row g-3 mb-4">
        <div className="col-md-3">
          <label className="form-label">Invoice ID</label>
          <input
            className="form-control"
            value={invoiceData.invoiceId}
            readOnly
          />
        </div>
        <div className="col-md-3">
          <label className="form-label">Date</label>
          <input
            type="date"
            className="form-control"
            name="date"
            value={invoiceData.date}
            onChange={handleChange}
          />
        </div>
        <div className="col-md-3">
          <label className="form-label">Platform</label>
          <select
            className="form-select"
            name="platform"
            value={invoiceData.platform}
            onChange={handleChange}
          >
            <option value="">Select Platform</option>
            <option value="BBSCART">BBSCART</option>
            <option value="Golldex">Golldex</option>
            <option value="DeliveryApp">BBSCART Delivery App</option>
            <option value="Emerjobs">Emerjobs</option>
          </select>
        </div>
        <div className="col-md-3">
          <label className="form-label">Status</label>
          <select
            className="form-select"
            name="status"
            value={invoiceData.status}
            onChange={handleChange}
          >
            <option value="Pending">Pending</option>
            <option value="Paid">Paid</option>
            <option value="Overdue">Overdue</option>
          </select>
        </div>
      </div>

      {/* Buyer & Seller */}
      <h5 className="mt-4">Buyer & Seller Info</h5>
      <div className="row g-3">
        <div className="col-md-3">
          <input
            placeholder="Buyer Name"
            className="form-control"
            name="buyerName"
            value={invoiceData.buyerName}
            onChange={handleChange}
          />
        </div>
        <div className="col-md-3">
          <input
            placeholder="Buyer GSTIN"
            className="form-control"
            name="buyerGSTIN"
            value={invoiceData.buyerGSTIN}
            onChange={handleChange}
          />
        </div>
        <div className="col-md-3">
          <input
            placeholder="Buyer State"
            className="form-control"
            name="buyerState"
            value={invoiceData.buyerState}
            onChange={handleChange}
          />
        </div>
        <div className="col-md-3">
          <input
            placeholder="Seller Name"
            className="form-control"
            name="sellerName"
            value={invoiceData.sellerName}
            onChange={handleChange}
          />
        </div>
        <div className="col-md-3">
          <input
            placeholder="Seller GSTIN"
            className="form-control"
            name="sellerGSTIN"
            value={invoiceData.sellerGSTIN}
            onChange={handleChange}
          />
        </div>
        <div className="col-md-3">
          <input
            placeholder="Seller State"
            className="form-control"
            name="sellerState"
            value={invoiceData.sellerState}
            onChange={handleChange}
          />
        </div>
      </div>

      {/* Items */}
      <h5 className="mt-4">Invoice Items</h5>
      <div className="row g-3">
        <div className="col-md-4">
          <input
            placeholder="Item Name"
            name="name"
            value={invoiceData.currentItem.name}
            onChange={handleItemChange}
            className="form-control"
          />
        </div>
        <div className="col-md-2">
          <input
            placeholder="Amount ₹"
            name="price"
            value={invoiceData.currentItem.price}
            onChange={handleItemChange}
            className="form-control"
          />
        </div>
        <div className="col-md-3">
          <input
            placeholder="HSN Code"
            name="hsn"
            value={invoiceData.currentItem.hsn}
            onChange={handleItemChange}
            className="form-control"
          />
        </div>
        <div className="col-md-2">
          <button className="btn btn-primary w-100" onClick={addItem}>
            Add Item
          </button>
        </div>
      </div>

      {/* GST */}
      <h5 className="mt-4">GST Breakdown</h5>
      <div className="row g-3">
        <div className="col-md-2">
          <label className="form-label">GST Type</label>
          <select
            className="form-select"
            name="gstType"
            value={invoiceData.gstType}
            onChange={handleChange}
          >
            <option value="">Select</option>
            <option value="CGST_SGST">CGST + SGST</option>
            <option value="IGST">IGST</option>
          </select>
        </div>
        <div className="col-md-2">
          <label className="form-label">CGST %</label>
          <input
            type="number"
            name="cgst"
            value={invoiceData.cgst}
            onChange={handleChange}
            className="form-control"
          />
        </div>
        <div className="col-md-2">
          <label className="form-label">SGST %</label>
          <input
            type="number"
            name="sgst"
            value={invoiceData.sgst}
            onChange={handleChange}
            className="form-control"
          />
        </div>
        <div className="col-md-2">
          <label className="form-label">IGST %</label>
          <input
            type="number"
            name="igst"
            value={invoiceData.igst}
            onChange={handleChange}
            className="form-control"
          />
        </div>
      </div>

      {/* Payment */}
      <h5 className="mt-4">Payment</h5>
      <div className="row g-3">
        <div className="col-md-3">
          <input
            placeholder="Amount Paid"
            name="amountPaid"
            value={invoiceData.amountPaid}
            onChange={handleChange}
            className="form-control"
          />
        </div>
        <div className="col-md-3">
          <select
            name="paymentMode"
            className="form-select"
            value={invoiceData.paymentMode}
            onChange={handleChange}
          >
            <option value="">Select Payment Mode</option>
            <option value="UPI">UPI</option>
            <option value="Wallet">Wallet</option>
            <option value="Bank Transfer">Bank Transfer</option>
            <option value="Cash">Cash</option>
          </select>
        </div>
        <div className="col-md-2 d-flex align-items-center">
          <div className="form-check me-3">
            <input
              type="checkbox"
              className="form-check-input"
              id="escrow"
              name="isEscrow"
              onChange={handleChange}
            />
            <label className="form-check-label" htmlFor="escrow">
              Escrow
            </label>
          </div>
          <div className="form-check">
            <input
              type="checkbox"
              className="form-check-input"
              id="partial"
              name="isPartialPayment"
              onChange={handleChange}
            />
            <label className="form-check-label" htmlFor="partial">
              Partial Payment
            </label>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="row mt-4">
        <div className="col-md-6">
          <textarea
            name="notes"
            placeholder="Notes / Terms"
            className="form-control"
            rows="3"
            onChange={handleChange}
          ></textarea>
        </div>
        <div className="col-md-3 mt-3">
          <button className="btn btn-success w-100">Create Invoice</button>
        </div>
      </div>
    </div>
  );
};

export default InvoiceCreatePage;

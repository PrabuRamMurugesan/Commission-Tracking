// InvoiceDetailPage.jsx (Page 4 of 18)

import React from "react";
import {
  Container,
  Row,
  Col,
  Card,
  Table,
  Button,
  Badge,
} from "react-bootstrap";

const InvoiceDetailPage = () => {
  return (
    <Container fluid className="mt-4">
      {/* HEADER */}
      <Row className="mb-3">
        <Col>
          <h4>Invoice Details</h4>
          <p className="text-muted">
            Invoice ID: INV00123 | Status: <Badge bg="warning">Partial</Badge>
          </p>
        </Col>
        <Col className="text-end">
          <Button variant="outline-primary" className="me-2">
            Download
          </Button>
          <Button variant="outline-secondary" className="me-2">
            Print
          </Button>
          <Button variant="outline-success" className="me-2">
            Edit
          </Button>
          <Button variant="outline-info" className="me-2">
            Escrow Info
          </Button>
          <Button variant="outline-dark">Status Tracker</Button>
        </Col>
      </Row>

      {/* BASIC INFO */}
      <Card className="mb-4">
        <Card.Header>Invoice Info</Card.Header>
        <Card.Body>
          <Row>
            <Col md={4}>
              <strong>Invoice Date:</strong> 01-Jun-2025
            </Col>
            <Col md={4}>
              <strong>Due Date:</strong> 05-Jun-2025
            </Col>
            <Col md={4}>
              <strong>Platform:</strong> BBSCART
            </Col>
          </Row>
          <Row className="mt-2">
            <Col md={4}>
              <strong>Invoice Type:</strong> Combo
            </Col>
            <Col md={4}>
              <strong>Payment Status:</strong> Partial
            </Col>
            <Col md={4}>
              <strong>Created By:</strong> Admin User
            </Col>
          </Row>
        </Card.Body>
      </Card>

      {/* CUSTOMER + VENDOR INFO */}
      <Card className="mb-4">
        <Card.Header>Customer & Vendor Details</Card.Header>
        <Card.Body>
          <Row>
            <Col md={6}>
              <h6>Customer Info</h6>
              <p>
                <strong>Name:</strong> Ravi Kumar
              </p>
              <p>
                <strong>Email:</strong> ravi@example.com
              </p>
              <p>
                <strong>GSTIN:</strong> 22AAAAA0000A1Z5
              </p>
              <p>
                <strong>State:</strong> Tamil Nadu
              </p>
              <p>
                <strong>Billing Address:</strong> Chennai, Tamil Nadu
              </p>
            </Col>
            <Col md={6}>
              <h6>Vendor Info</h6>
              <p>
                <strong>Store:</strong> Thiaworld Gold
              </p>
              <p>
                <strong>Vendor ID:</strong> VND1234
              </p>
              <p>
                <strong>GSTIN:</strong> 33BBBBB1111B2Z6
              </p>
              <p>
                <strong>State:</strong> Puducherry
              </p>
              <p>
                <strong>Pickup Address:</strong> Puducherry
              </p>
            </Col>
          </Row>
        </Card.Body>
      </Card>

      {/* ITEMIZED TABLE WITH GST */}
      <Card className="mb-4">
        <Card.Header>Items / Services</Card.Header>
        <Card.Body className="p-0">
          <Table striped bordered responsive>
            <thead>
              <tr>
                <th>#</th>
                <th>Item Name</th>
                <th>HSN Code</th>
                <th>Qty</th>
                <th>Rate</th>
                <th>Discount</th>
                <th>Tax % (CGST+SGST)</th>
                <th>Tax ₹</th>
                <th>Total</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>1</td>
                <td>Gold Necklace</td>
                <td>7113</td>
                <td>1</td>
                <td>₹15,000</td>
                <td>0%</td>
                <td>5% (2.5% + 2.5%)</td>
                <td>₹750</td>
                <td>₹15,750</td>
              </tr>
            </tbody>
          </Table>
        </Card.Body>
      </Card>

      {/* PAYMENT SUMMARY WITH GST */}
      {/* <Card className="mb-4">
        <Card.Header>Payment Summary</Card.Header>
        <Card.Body>
          <Row>
            <Col md={4}>
              <strong>Taxable Subtotal:</strong> ₹15,000
            </Col>
            <Col md={4}>
              <strong>CGST (2.5%):</strong> ₹375
            </Col>
            <Col md={4}>
              <strong>SGST (2.5%):</strong> ₹375
            </Col>
          </Row>
          <Row className="mt-2">
            <Col md={4}>
              <strong>Platform Fee:</strong> ₹200
            </Col>
            <Col md={4}>
              <strong>Paid via Wallet:</strong> ₹8,000
            </Col>
            <Col md={4}>
              <strong>Escrow Amount:</strong> ₹7,750
            </Col>
          </Row>
          <Row className="mt-2">
            <Col md={4}>
              <strong>Total Invoice Value:</strong> ₹15,750
            </Col>
            <Col md={4}>
              <strong>Amount Paid:</strong> ₹8,000
            </Col>
            <Col md={4}>
              <strong>Pending Amount:</strong> ₹7,750
            </Col>
          </Row>
        </Card.Body>
      </Card> */}
      {/* PAYMENT SUMMARY WITH GST */}
      <Card className="mb-4">
        <Card.Header>Payment Summary & GST Breakdown</Card.Header>
        <Card.Body>
          <Row>
            <Col md={4}>
              <strong>Taxable Subtotal:</strong> ₹15,000
            </Col>
            <Col md={4}>
              <strong>Platform Fee:</strong> ₹200
            </Col>
            <Col md={4}>
              <strong>Invoice Type:</strong> Intra-State
            </Col>
          </Row>
          <hr />
          <Row className="mb-2">
            <Col md={4}>
              <strong>CGST %:</strong> <span className="text-muted">2.5%</span>
            </Col>
            <Col md={4}>
              <strong>CGST ₹:</strong> <span className="text-muted">₹375</span>
            </Col>
          </Row>
          <Row className="mb-2">
            <Col md={4}>
              <strong>SGST %:</strong> <span className="text-muted">2.5%</span>
            </Col>
            <Col md={4}>
              <strong>SGST ₹:</strong> <span className="text-muted">₹375</span>
            </Col>
          </Row>
          <Row className="mb-2">
            <Col md={4}>
              <strong>IGST %:</strong> <span className="text-muted">0%</span>
            </Col>
            <Col md={4}>
              <strong>IGST ₹:</strong> <span className="text-muted">₹0</span>
            </Col>
          </Row>
          <hr />
          <Row className="mb-2">
            <Col md={4}>
              <strong>Total Tax Amount:</strong> ₹750
            </Col>
            <Col md={4}>
              <strong>Total Invoice Value:</strong> ₹15,750
            </Col>
            <Col md={4}>
              <strong>Paid via Wallet:</strong> ₹8,000
            </Col>
          </Row>
          <Row>
            <Col md={4}>
              <strong>Escrow Amount:</strong> ₹7,750
            </Col>
            <Col md={4}>
              <strong>Amount Paid:</strong> ₹8,000
            </Col>
            <Col md={4}>
              <strong>Pending Amount:</strong> ₹7,750
            </Col>
          </Row>
        </Card.Body>
      </Card>

      {/* GST LOGIC NOTE */}
      <Card className="mb-4">
        <Card.Header>GST Information</Card.Header>
        <Card.Body>
          <p>
            <strong>Invoice GST Type:</strong> Intra-State (CGST + SGST)
          </p>
          <p>
            <strong>Reverse Charge Applicable:</strong> No
          </p>
          <p>
            <strong>GST Filing Month:</strong> June 2025
          </p>
          <p className="text-muted small">
            This invoice is automatically linked to GSTR-1 for filing
            compliance.
          </p>
        </Card.Body>
      </Card>

      {/* TERMS + LINKS */}
      <Card className="mb-4">
        <Card.Header>Terms & Notes</Card.Header>
        <Card.Body>
          <p>
            Payment to be completed within 4 days. Escrow will be released upon
            confirmation of delivery. For refund-related queries, please contact
            support@bbscart.com.
          </p>
        </Card.Body>
      </Card>

      <Row className="mb-5">
        <Col>
          <Button variant="outline-dark" className="me-2">
            View GST Breakdown
          </Button>
          <Button variant="outline-info" className="me-2">
            Wallet History
          </Button>
          <Button variant="outline-secondary" className="me-2">
            View Customer Invoice
          </Button>
          <Button variant="outline-warning" className="me-2">
            AI Suggest Action
          </Button>
          <Button variant="outline-danger">Cancel / Refund</Button>
        </Col>
      </Row>
    </Container>
  );
};

export default InvoiceDetailPage;

// InvoiceListPage.jsx (Page 3 of 18) – Functional Version

import React, { useState, useEffect } from "react";
import {
  Container,
  Row,
  Col,
  Card,
  Form,
  Button,
  Table,
  Badge,
  InputGroup,
} from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const dummyInvoices = Array.from({ length: 28 }).map((_, i) => ({
  id: `INV00${100 + i}`,
  customer: `Customer ${i + 1}`,
  platform: ["BBSCART", "Golddex", "Delivery", "Emerjobs"][i % 4],
  invoiceDate: "2025-06-01",
  dueDate: "2025-06-05",
  total: 5000 + i * 100,
  paid: i % 3 === 0 ? 5000 + i * 100 : 3000 + i * 50,
  status: i % 3 === 0 ? "Paid" : i % 3 === 1 ? "Unpaid" : "Partial",
  type: i % 4 === 0 ? "Combo" : i % 4 === 1 ? "Secure Plan" : "Sale",
  payment: ["UPI", "Wallet", "COD", "EMI"][i % 4],
  gst: "CGST/SGST",
}));

const rowsPerPage = 10;

const InvoiceListPage = () => {
  const [invoices, setInvoices] = useState([]);
  const [totalPages, setTotalPages] = useState(1);
  const [totalCount, setTotalCount] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [platformFilter, setPlatformFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [filters, setFilters] = useState({
    platforms: [],
    paymentStatuses: [],
  });
  const rowsPerPage = 10;

  const navigate = useNavigate();
  // const totalPages = Math.ceil(dummyInvoices.length / rowsPerPage);

  const paginatedInvoices = dummyInvoices.slice(
    (currentPage - 1) * rowsPerPage,
    currentPage * rowsPerPage
  );

  const handlePageChange = (page) => {
    if (page > 0 && page <= totalPages) setCurrentPage(page);
  };
  useEffect(() => {
    fetchFilters();
    fetchInvoices();
  }, [currentPage]);

  const fetchFilters = async () => {
    try {
      const res = await axios.get("/api/invoices/filters/options");
      setFilters({
        platforms: res.data.data.platforms,
        paymentStatuses: res.data.data.paymentStatuses,
      });
    } catch (err) {
      console.error("Failed to load filters", err);
    }
  };

  const fetchInvoices = async () => {
    try {
      const params = {
        page: currentPage,
        limit: rowsPerPage,
        platform: platformFilter || undefined,
        paymentStatus: statusFilter || undefined,
        search: searchQuery || undefined,
      };
      const res = await axios.get("/api/invoices", { params });
      setInvoices(res.data.data);
      setTotalPages(res.data.pages);
      setTotalCount(res.data.total);
    } catch (err) {
      console.error("Failed to fetch invoices", err);
    }
  };
  
  return (
    <Container fluid className="mt-4">
      <Row className="mb-3">
        <Col md={6}>
          <h4>Invoice List</h4>
        </Col>
        <Col md={6} className="text-end">
          <Button variant="success" className="me-2">
            + Create Invoice
          </Button>
          <Button variant="outline-primary" className="me-2">
            Export
          </Button>
          <Button variant="outline-dark">Refresh</Button>
        </Col>
      </Row>

      <Card className="mb-4">
        <Card.Header>Filter Invoices</Card.Header>
        <Card.Body>
          <Row className="gy-2">
            <Col md={3}>
              <Form.Group>
                <Form.Label>Platform</Form.Label>
                <Form.Select>
                  <option>All</option>
                  <option>BBSCART</option>
                  <option>Golddex</option>
                  <option>Delivery</option>
                  <option>Emerjobs</option>
                </Form.Select>
              </Form.Group>
            </Col>
            <Col md={3}>
              <Form.Group>
                <Form.Label>Status</Form.Label>
                <Form.Select>
                  <option>All</option>
                  <option>Paid</option>
                  <option>Unpaid</option>
                  <option>Partial</option>
                </Form.Select>
              </Form.Group>
            </Col>
            <Col md={6}>
              <Form.Group>
                <Form.Label>Search</Form.Label>
                <InputGroup>
                  <Form.Control type="text" placeholder="INV ID / Customer" />
                  <Button variant="primary">Search</Button>
                </InputGroup>
              </Form.Group>
            </Col>
          </Row>
          <div className="mt-3">
            <Button variant="primary" className="me-2">
              Apply Filters
            </Button>
            <Button variant="secondary">Reset</Button>
          </div>
        </Card.Body>
      </Card>

      <Card className="mb-4">
        <Card.Header>All Invoices</Card.Header>
        <Card.Body className="p-0">
          <Table responsive hover striped bordered>
            <thead className="table-light">
              <tr>
                <th>#</th>
                <th>Invoice ID</th>
                <th>Customer</th>
                <th>Platform</th>
                <th>Invoice Date</th>
                <th>Due Date</th>
                <th>Total</th>
                <th>Paid</th>
                <th>Status</th>
                <th>Type</th>
                <th>Payment</th>
                <th>GST</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {invoices.map((inv, idx) => (
                <tr key={inv._id}>
                  <td>{(currentPage - 1) * rowsPerPage + idx + 1}</td>
                  <td>
                    <a href="#">{inv.invoiceNumber}</a>
                  </td>
                  <td>{inv.customer?.name || "-"}</td>
                  <td>{inv.platform}</td>
                  <td>{new Date(inv.createdAt).toLocaleDateString()}</td>
                  <td>
                    {new Date(
                      inv.nextDueDate || inv.createdAt
                    ).toLocaleDateString()}
                  </td>
                  <td>₹{inv.totalAmount.toLocaleString("en-IN")}</td>
                  <td>₹{inv.totalAmount.toLocaleString("en-IN")}</td>
                  <td>
                    <Badge
                      bg={
                        inv.paymentStatus === "Paid"
                          ? "success"
                          : inv.paymentStatus === "Unpaid"
                          ? "danger"
                          : "warning"
                      }
                    >
                      {inv.paymentStatus}
                    </Badge>
                  </td>
                  <td>{inv.type || "-"}</td>
                  <td>{inv.paymentMethod || "-"}</td>
                  <td>
                    {(inv.gst?.cgst || 0) +
                      (inv.gst?.sgst || 0) +
                      (inv.gst?.igst || 0)}
                    %
                  </td>
                  <td>
                    <Button
                      size="sm"
                      variant="outline-primary"
                      onClick={() => navigate(`/invoice-details/${inv._id}`)}
                    >
                      View
                    </Button>{" "}
                    <Button
                      size="sm"
                      variant="outline-success"
                      onClick={() => navigate(`/invoice-edit/${inv._id}`)}
                    >
                      Edit
                    </Button>{" "}
                    <Button size="sm" variant="outline-dark">
                      Print
                    </Button>{" "}
                    <Button size="sm" variant="outline-dark">
                      CustomerPreview
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </Table>
        </Card.Body>
      </Card>

      {/* Pagination Controls */}
      <Row>
        <Col md={6}>
          <p className="text-muted">
            Showing {(currentPage - 1) * rowsPerPage + 1} to{" "}
            {Math.min(currentPage * rowsPerPage, dummyInvoices.length)} of{" "}
            {dummyInvoices.length} invoices
          </p>
        </Col>
        <Col md={6} className="text-end">
          <Button
            size="sm"
            variant="outline-secondary"
            onClick={() => handlePageChange(currentPage - 1)}
            className="me-2"
          >
            Prev
          </Button>
          {[...Array(totalPages)].map((_, i) => (
            <Button
              key={i}
              size="sm"
              variant={i + 1 === currentPage ? "primary" : "outline-secondary"}
              onClick={() => handlePageChange(i + 1)}
              className="me-1"
            >
              {i + 1}
            </Button>
          ))}
          <Button
            size="sm"
            variant="outline-secondary"
            onClick={() => handlePageChange(currentPage + 1)}
          >
            Next
          </Button>
        </Col>
      </Row>
    </Container>
  );
};

export default InvoiceListPage;
